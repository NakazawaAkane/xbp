ok = 0
ng = 0

print("なぞなぞゲーム")
a = input("赤ちゃんしかいない国はどこ？")
b = input("クマが問題を解けない場所は？")
c = input("全員が女の子の四つ子がお正月に披露するものは何でしょうか？")
d = input("パパとママは２回ずつ会えるのに、父と母は１回も会えませんこれ何のこと？")

if a == "ニュージーランド":
    print("正解")
    ok = ok + 1
else:
    print("不正解")
    ng = ng + 1


if b == "熊本県" or b == "熊本" or b == "くまもとけん" or b == "くまもと":
    print("正解")
    ok = ok + 1
else:
    print("不正解")
    ng = ng + 1


if c == "獅子舞" or c == "ししまい" in c:
    print("正解")
    ok = ok + 1
else:
    print("不正解")
    ng = ng + 1


if d == "唇" or d == "くちびる" or d == "口":
    print("正解")
    ok = ok + 1
else:
    print("不正解")
    ng = ng + 1

print("おわりーーー　あなたの正解数は", ok, "正解率は", ok/(ok+ng)*100, "％です")